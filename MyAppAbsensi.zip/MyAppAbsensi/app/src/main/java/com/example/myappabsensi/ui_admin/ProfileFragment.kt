package com.example.myappabsensi.ui_admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.myappabsensi.R
import com.example.myappabsensi.utils.ui_user.userData
import com.example.myappabsensi.utils.userDataa
import com.google.firebase.database.*

class ProfileFragment : Fragment() {

    private lateinit var etnikk: TextView
    private lateinit var etLevell: TextView
    private lateinit var etNamaa: TextView
    private lateinit var etjkk: TextView
    private lateinit var etlahirr: TextView
    private lateinit var etHpp: TextView
    private lateinit var etAlamatt: TextView
    private lateinit var btnSavedataa: Button

    private lateinit var databaseRef: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_profile, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etnikk = view.findViewById(R.id.etnikk)
        etLevell = view.findViewById(R.id.etLevell)
        etNamaa = view.findViewById(R.id.etNamaa)
        etjkk = view.findViewById(R.id.etjkk)
        etlahirr = view.findViewById(R.id.etlahirr)
        etHpp = view.findViewById(R.id.etHpp)
        etAlamatt = view.findViewById(R.id.etAlamatt)
        btnSavedataa = view.findViewById(R.id.btn_savedataa)


        btnSavedataa.setOnClickListener {
            saveDataToDatabase()
        }
        databaseRef = FirebaseDatabase.getInstance().reference

        // Mengambil data dari database dan menampilkannya
        getDataFromDatabase()
    }

    private fun getDataFromDatabase() {
        val userDataRef = databaseRef.child("userData").child("433236545644232")


        userDataRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userData = snapshot.getValue(userDataa::class.java)
                if (userData != null) {
                    // Lakukan sesuatu dengan data pengguna
                    val nik = userData.nik
                    val level = userData.level
                    val fullname = userData.fullname
                    val lahir = userData.date_of_birth
                    val jk = userData.jk
                    val phone = userData.phone
                    val address = userData.address

                    // Tampilkan data pengguna di aplikasi
                    etnikk.text = nik
                    etLevell.text = level
                    etNamaa.text = fullname
                    etlahirr.text = lahir
                    etjkk.text = jk
                    etHpp.text = phone
                    etAlamatt.text = address
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Menampilkan pesan kesalahan jika terjadi error saat mengambil data
                Toast.makeText(
                    requireContext(),
                    "Terjadi kesalahan saat mengambil data pengguna.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

        private fun saveDataToDatabase() {
            val userDataRef = databaseRef.child("userData").child("433236545644232")

            userDataRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val existingUserData = snapshot.getValue(userDataa::class.java)

                    if (existingUserData != null) {
                        val nik = etnikk.text.toString()
                        val address = etAlamatt.text.toString()
                        val fullname = etNamaa.text.toString()
                        val jk = etjkk.text.toString()
                        val level = etLevell.text.toString()
                        val phone = etHpp.text.toString()
                        val existingPassword = existingUserData.password
                        val lahir = etlahirr.text.toString()

                        // Create a new instance of UserData with the updated fields
                        val userData = userDataa(
                            nik = nik,
                            address = address,
                            date_of_birth = lahir,
                            fullname = fullname,
                            jk = jk,
                            level = level,
                            password = existingPassword,
                            phone = phone
                        )

                        // Simpan data pengguna ke database
                        userDataRef.setValue(userData)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(
                                        requireContext(),
                                        "Data pengguna berhasil disimpan.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        requireContext(),
                                        "Terjadi kesalahan saat menyimpan data pengguna.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Menampilkan pesan kesalahan jika terjadi error saat mengambil data
                    Toast.makeText(
                        requireContext(),
                        "Terjadi kesalahan saat mengambil data pengguna.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }

