package com.example.myappabsensi

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.myappabsensi.databinding.ActivityAdminBinding
import com.example.myappabsensi.ui_admin.AbsensiFragment
import com.example.myappabsensi.ui_admin.ProfileFragment
import com.example.myappabsensi.ui_admin.LaporanKerjaFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class AdminActivity : AppCompatActivity() {

    val fragmentProfile: Fragment = ProfileFragment()
    val fragmentAbsensi: Fragment = AbsensiFragment()
    val fragmentLaporanKerja: Fragment = LaporanKerjaFragment()
    val fm: FragmentManager = supportFragmentManager
    var active: Fragment = fragmentProfile

    lateinit var binding: ActivityAdminBinding

    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var menu: Menu
    private lateinit var menuItem: MenuItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        supportActionBar?.hide()
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        buttonNavigation()
    }

    private fun buttonNavigation() {
        fm.beginTransaction().add(R.id.container1, fragmentProfile).show(fragmentProfile).commit()
        fm.beginTransaction().add(R.id.container1, fragmentAbsensi).hide(fragmentAbsensi).commit()
        fm.beginTransaction().add(R.id.container1, fragmentLaporanKerja).hide(fragmentLaporanKerja).commit()

        bottomNavigationView = binding.bottommview
        menu = bottomNavigationView.menu
        menuItem = menu.getItem(0)
        menuItem.isChecked = true

        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_profile-> {
                    callFrag(0, fragmentProfile)
                }
                R.id.navigation_laporanabsensi -> {
                    callFrag(1, fragmentAbsensi)
                }
                R.id.navigation_laporankerja -> {
                    callFrag(2, fragmentLaporanKerja)
                }
            }
            false
        }
    }

    private fun callFrag(index: Int, fragment: Fragment) {
        menuItem = menu.getItem(index)
        menuItem.isChecked = true
        fm.beginTransaction().hide(active).show(fragment).commit()
        active = fragment
    }
}
