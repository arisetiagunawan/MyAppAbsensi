import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.myappabsensi.R
import com.example.myappabsensi.AbsenActivity
import com.example.myappabsensi.utils.ui_user.userData
import com.example.myappabsensi.utils.userDataa
import com.google.firebase.database.*

class AbsenFragment : Fragment() {

    private lateinit var etnik: TextView
    private lateinit var etLevel: TextView
    private lateinit var etNama: TextView
    private lateinit var etjk: TextView
    private lateinit var etlahir: TextView
    private lateinit var etHp: TextView
    private lateinit var etAlamat: TextView
    private lateinit var btnSavedata: Button
    private lateinit var btnAbsen: Button
    private lateinit var databaseRef: DatabaseReference

    private val LOCATION_PERMISSION_REQUEST_CODE = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_absen, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etnik = view.findViewById(R.id.etnik)
        etLevel = view.findViewById(R.id.etLevel)
        etNama = view.findViewById(R.id.etNama)
        etjk = view.findViewById(R.id.etjk)
        etlahir = view.findViewById(R.id.etlahir)
        etHp = view.findViewById(R.id.etHp)
        etAlamat = view.findViewById(R.id.etAlamat)
        btnSavedata = view.findViewById(R.id.btn_savedata)
        btnAbsen = view.findViewById(R.id.btn_Absen)

        btnSavedata.setOnClickListener {
            saveDataToDatabase()
        }

        btnAbsen.setOnClickListener {
            if (checkLocationPermission()) {
                startAbsenActivity()
            } else {
                requestLocationPermission()
            }
        }

        databaseRef = FirebaseDatabase.getInstance().reference

        // Mengambil data dari database dan menampilkannya
        getDataFromDatabase()
    }

    private fun checkLocationPermission(): Boolean {
        val permission = Manifest.permission.ACCESS_FINE_LOCATION
        val result = ContextCompat.checkSelfPermission(requireContext(), permission)
        return result == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        val permission = Manifest.permission.ACCESS_FINE_LOCATION

        if (shouldShowRequestPermissionRationale(permission)) {
            AlertDialog.Builder(requireContext())
                .setTitle("Izin Lokasi Diperlukan")
                .setMessage("Aplikasi ini membutuhkan akses lokasi untuk melakukan absen.")
                .setPositiveButton("OK") { dialog, which ->
                    requestPermissions(arrayOf(permission), LOCATION_PERMISSION_REQUEST_CODE)
                }
                .setNegativeButton("Batal") { dialog, which ->
                    Toast.makeText(
                        requireContext(),
                        "Izin lokasi tidak diberikan. Tidak dapat melakukan absen.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .create()
                .show()
        } else {
            requestPermissions(arrayOf(permission), LOCATION_PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startAbsenActivity()
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Izin lokasi tidak diberikan. Tidak dapat melakukan absen.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun startAbsenActivity() {
        val intent = Intent(requireContext(), AbsenActivity::class.java)
        startActivity(intent)
    }

    private fun getDataFromDatabase() {
        val userDataRef = databaseRef.child("userData").child("534564675545467")

        userDataRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userData = snapshot.getValue(userData::class.java)
                if (userData != null) {
                    val nik = userData.nik
                    val level = userData.level
                    val fullname = userData.fullname
                    val lahir = userData.date_of_birth
                    val jk = userData.jk
                    val phone = userData.phone
                    val address = userData.address

                    etnik.text = nik
                    etLevel.text = level
                    etNama.text = fullname
                    etlahir.text = lahir
                    etjk.text = jk
                    etHp.text = phone
                    etAlamat.text = address
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    requireContext(),
                    "Terjadi kesalahan saat mengambil data pengguna.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun saveDataToDatabase() {
        val userDataRef = databaseRef.child("userData").child("534564675545467")

        userDataRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val existingUserData = snapshot.getValue(userDataa::class.java)

                if (existingUserData != null) {
                    val nik = etnik.text.toString()
                    val address = etAlamat.text.toString()
                    val fullname = etNama.text.toString()
                    val jk = etjk.text.toString()
                    val level = etLevel.text.toString()
                    val phone = etHp.text.toString()
                    val existingPassword = existingUserData.password
                    val lahir = etlahir.text.toString()

                    val userData = userDataa(
                        nik = nik,
                        address = address,
                        date_of_birth = lahir,
                        fullname = fullname,
                        jk = jk,
                        level = level,
                        password = existingPassword,
                        phone = phone
                    )

                    userDataRef.setValue(userData)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Toast.makeText(
                                    requireContext(),
                                    "Data pengguna berhasil disimpan.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    requireContext(),
                                    "Terjadi kesalahan saat menyimpan data pengguna.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    requireContext(),
                    "Terjadi kesalahan saat mengambil data pengguna.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
