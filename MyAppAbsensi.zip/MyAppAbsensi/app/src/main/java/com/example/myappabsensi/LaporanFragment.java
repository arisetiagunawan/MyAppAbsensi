package com.example.myappabsensi;

import android.app.Activity;

public class LaporanFragment extends Activity {
}
