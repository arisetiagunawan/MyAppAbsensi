package com.example.myappabsensi

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myappabsensi.utils.userDataa
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {
    private lateinit var database: DatabaseReference
    private lateinit var context: Context
    private lateinit var pref: Preferences
    private lateinit var query: Query
    private lateinit var valueEventListener: ValueEventListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        database = FirebaseDatabase.getInstance().reference
        context = this
        pref = Preferences(context)

        val btnLogin = findViewById<Button>(R.id.btn_login)
        val idUsername = findViewById<EditText>(R.id.idusername)
        val idPassword = findViewById<EditText>(R.id.idpassword)

        btnLogin.setOnClickListener {
            val username: String = idUsername.text.toString()
            val password: String = idPassword.text.toString()
            if (username.isEmpty()) {
                idUsername.error = "Data tidak boleh kosong"
                idUsername.requestFocus()
            } else if (password.isEmpty()) {
                idPassword.error = "Data tidak boleh kosong"
                idPassword.requestFocus()
            } else {
                valueEventListener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        Log.d("MainActivity", "Snapshot exists: ${snapshot.exists()}")
                        if (snapshot.exists()) {
                            var isUsernameMatched = false
                            for (item in snapshot.children) {
                                val user = item.getValue(userDataa::class.java)
                                if (user != null && user.password == password) {
                                    isUsernameMatched = true
                                    pref.prefStatus = true
                                    pref.prefLevel = user.level
                                    val intent: Intent = if (user.level == "Pengawas Penyapu") {
                                        Intent(context, AdminActivity::class.java)
                                    } else {
                                        Intent(context, UserActivity::class.java)
                                    }
                                    startActivity(intent)
                                    finish()
                                    break
                                }
                            }
                            if (!isUsernameMatched) {
                                Toast.makeText(
                                    context,
                                    "Kata sandi belum sesuai",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            Toast.makeText(context, "NIK belum terdaftar", Toast.LENGTH_LONG)
                                .show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e("MainActivity", "Database error: ${error.message}")
                        Toast.makeText(context, error.message, Toast.LENGTH_LONG).show()
                    }
                }

                query = database.child("userData").orderByChild("nik").equalTo(username)
                query.addListenerForSingleValueEvent(valueEventListener)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val loggedInUser = pref.prefStatus
        val level = pref.prefLevel

        if (loggedInUser) {
            val intent: Intent = if (level == "Pengawas Penyapu") {
                Intent(context, AdminActivity::class.java)
            } else {
                Intent(context, UserActivity::class.java)
            }
            startActivity(intent)
            finish()
        }
    }

    override fun onStop() {
        super.onStop()
        if (::query.isInitialized) {
            query.removeEventListener(valueEventListener)
        }
    }

}
