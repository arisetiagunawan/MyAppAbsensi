package com.example.myappabsensi.utils.ui_user

class userData(
    val address: String = "",
    val fullname: String= "",
    val level: String= "",
    val nik: String= "",
    val date_of_birth: String= "",
    val jk: String= "",
    val phone: String= "",

)
{
    constructor() : this("", "", "", "", "","","")

}
