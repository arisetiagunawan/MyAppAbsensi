package com.example.myappabsensi.ui_admin

class userData2(
    val address: String = "",
    val fullname: String= "",
    val level: String= "",
    val nik: String= "",
    val date_of_birth: String= "",
    val jk: String= "",
    val phone: String= "",

)
{
    constructor() : this("", "", "", "", "","","")

}
