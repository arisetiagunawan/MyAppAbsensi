package com.example.myappabsensi.utils

data class userDataa(

    val nik: String? =null,
    val address: String? = null,
    val date_of_birth: String? = null,
    val fullname: String? = null,
    val jk: String? = null,
    val level: String? = null,
    val password: String? = null,
    val phone: String? = null

)